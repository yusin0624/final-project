#include "raylib.h"

int main(void)
{
    InitWindow(600, 600, "raylib [core] example - basic window");

    while (!WindowShouldClose())
    {
        BeginDrawing();
            ClearBackground(RAYWHITE);
            DrawText("Congrats! You created your first window!", 120, 300, 20, LIGHTGRAY);
        EndDrawing();
    }

    CloseWindow();

    return 0;
}